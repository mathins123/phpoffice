<?php

use PhpOffice\PhpWord\SimpleType\VerticalJc;

include_once 'Sample_Header.php';

// New Word Document
echo date('H:i:s'), ' Create new PhpWord object', EOL;
$phpWord = new PhpOffice\PhpWord\PhpWord();

// New portrait section
$section = $phpWord->addSection(['borderColor' => '00FF00', 'borderSize' => 12]);
$section->addText('I am placed on a default section.');

// New landscape section
$section = $phpWord->addSection(['orientation' => 'landscape']);
$section->addText('I am placed on a landscape section. Every page starting from this section will be landscape style.');
$section->addPageBreak();
$section->addPageBreak();

// New portrait section
$section = $phpWord->addSection(
    ['paperSize' => 'Folio', 'marginLeft' => 600, 'marginRight' => 600, 'marginTop' => 600, 'marginBottom' => 600]
);
$section->addText('This section uses other margins with folio papersize.');

// The text of this section is vertically centered
$section = $phpWord->addSection(
    ['vAlign' => VerticalJc::CENTER]
);
$section->addText('This section is vertically centered.');

// New portrait section with Header & Footer
$section = $phpWord->addSection(
    [
        'marginLeft' => 200,
        'marginRight' => 200,
        'marginTop' => 200,
        'marginBottom' => 200,
        'headerHeight' => 50,
        'footerHeight' => 50,
    ]
);
$section->addText('This section and we play with header/footer height.');
$section->addHeader()->addText('Header');
$section->addFooter()->addText('Footer');

// Save file
echo write($phpWord, basename(__FILE__, '.php'), $writers);
if (!CLI) {
    include_once 'Sample_Footer.php';
}
