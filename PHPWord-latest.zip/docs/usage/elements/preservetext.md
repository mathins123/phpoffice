# Preserve text

The ``addPreserveText`` method is used to add a page number or page count to headers or footers.

``` php
<?php

$footer->addPreserveText('Page {PAGE} of {NUMPAGES}.');
```